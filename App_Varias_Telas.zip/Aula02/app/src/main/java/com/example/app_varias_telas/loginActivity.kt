package com.example.app_varias_telas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class loginActivity : AppCompatActivity() {
    private lateinit var btLogin: Button
    private lateinit var btSair: Button
    private lateinit var etLogarNome: EditText
    private lateinit var etLogarSenha: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        btLogin = findViewById<Button>(R.id.btLogin)
        btSair = findViewById<Button>(R.id.btSair)
        etLogarNome = findViewById<EditText>(R.id.etLogarNome)
        etLogarSenha = findViewById<EditText>(R.id.etLogarSenha)

        btLogin.setOnClickListener {
            var resultNome = etLogarNome.text.toString()
            var resultSenha = etLogarSenha.text.toString()

            if(resultNome == "Arthur" && resultSenha == "kotlin"){
                var telaMenu: Intent
                telaMenu = Intent(this, menu_activity::class.java)
                startActivity(telaMenu)
            }else{
                var msgErro = "Nome ou senha invalidos"
                Toast.makeText(this,msgErro , Toast.LENGTH_SHORT).show()
            }
        }

        btSair.setOnClickListener {
            finish()
        }
    }
}
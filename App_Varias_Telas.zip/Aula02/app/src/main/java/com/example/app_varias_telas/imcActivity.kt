package com.example.app_varias_telas

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class imcActivity : AppCompatActivity() {
    private lateinit var etPeso: EditText
    private lateinit var etAltura: EditText
    private lateinit var btCalcular2: Button
    private lateinit var btLimpar4: Button
    private lateinit var btSair4: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_imc)
        etPeso = findViewById<EditText>(R.id.etPeso)
        etAltura = findViewById<EditText>(R.id.etAltura)

        btCalcular2 = findViewById<Button>(R.id.btCalcular2)
        btLimpar4 = findViewById<Button>(R.id.btLimpar4)
        btSair4 = findViewById<Button>(R.id.btSair4)

        tvResult = findViewById<TextView>(R.id.tvResult)

        btCalcular2.setOnClickListener {
            var peso: Double
            var altura: Double
            var imc: Double

            peso = etPeso.text.toString().toDouble()
            altura = etAltura.text.toString().toDouble()

            imc = peso /( altura * altura)
            if (imc < 18.5) {
                tvResult.text = "Abaixo do peso"
            } else if (imc >= 18.5 && imc < 25.0) {
                tvResult.text = "Peso normal"
            } else if (imc >= 25.0 && imc < 30.0) {
                tvResult.text = "Sobrepeso"
            } else if (imc >= 30.0 && imc < 35.0) {
                tvResult.text = "Obesidade Grau I"
            } else if (imc >= 35.0 && imc < 40.0) {
                tvResult.text = "Obesidade Grau II"
            } else {
                tvResult.text = "Obesidade Grau III"
            }
        }

        btLimpar4.setOnClickListener {
            etPeso.setText("")
            etAltura.setText("")
            tvResult.text = ""
            etPeso.requestFocus()
        }

        btSair4.setOnClickListener {
            finishAndRemoveTask()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
package com.example.app_varias_telas

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class notaActivity : AppCompatActivity() {
    private lateinit var etNota1: EditText
    private lateinit var etNota2: EditText
    private lateinit var etFaltas: EditText
    private lateinit var btCalcular: Button
    private lateinit var btLimpar: Button
    private lateinit var btSair3: Button
    private lateinit var tvNotaFinal: TextView
    private lateinit var tvSituacao: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_nota)
        etNota1 = findViewById<EditText>(R.id.etPeso)
        etNota2 = findViewById<EditText>(R.id.etAltura)
        etFaltas = findViewById<EditText>(R.id.etFaltas)

        btCalcular = findViewById<Button>(R.id.btCalcular2)
        btLimpar = findViewById<Button>(R.id.btLimpar4)
        btSair3 = findViewById<Button>(R.id.btSair3)

        tvNotaFinal = findViewById<TextView>(R.id.tvNotaFinal)
        tvSituacao = findViewById<TextView>(R.id.tvResult)

        btCalcular.setOnClickListener {
            var nota1: Double
            var nota2: Double
            var faltas: Int
            var notaFinal: Double
            var situacao: String

            nota1 = etNota1.text.toString().toDouble()
            nota2 = etNota2.text.toString().toDouble()
            faltas = etFaltas.text.toString().toInt()

            notaFinal = (nota1 + nota2)/2
            if(faltas >= 20 || notaFinal < 6.0){
                situacao = "Reprovado"
            }else{
                situacao = "Aprovado"
            }

            tvNotaFinal.text = "$notaFinal"
            tvSituacao.text = situacao

        }

        btLimpar.setOnClickListener {
            etNota1.setText("")
            etNota2.setText("")
            etFaltas.setText("")
            tvSituacao.text = ""
            tvNotaFinal.text = ""
            etNota1.requestFocus()
        }

        btSair3.setOnClickListener {
            finishAndRemoveTask()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
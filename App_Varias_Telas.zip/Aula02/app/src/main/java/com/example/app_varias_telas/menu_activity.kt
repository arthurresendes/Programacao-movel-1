package com.example.app_varias_telas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class menu_activity : AppCompatActivity() {
    private lateinit var btImc: Button
    private lateinit var btSair2: Button
    private lateinit var btNota: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        btImc = findViewById<Button>(R.id.btImc)
        btNota = findViewById<Button>(R.id.btNota)
        btSair2 = findViewById<Button>(R.id.btSair2)

        btImc.setOnClickListener {
            var telaImc: Intent
            telaImc = Intent(this, imcActivity::class.java)
            startActivity(telaImc)
        }

        btNota.setOnClickListener {
            var telaNota: Intent
            telaNota = Intent(this, notaActivity::class.java)
            startActivity(telaNota)
        }

        btSair2.setOnClickListener {
            finish()
        }
    }
}